import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

export async function POST(req: Request) {
  const form = await req.formData();
  const sid = String(form.get("MessageSid") || "");
  const status = String(form.get("MessageStatus") || "");
  const errorMessage = String(form.get("ErrorMessage") || "");

  if (!sid || !status) {
    return NextResponse.json({ success: false }, { status: 400 });
  }

  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!url || !key) {
    return NextResponse.json({ success: false }, { status: 500 });
  }

  const admin = createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
  });

  const { error } = await admin
    .from("sms_logs")
    .update({
      status,
      error_message: errorMessage || null,
    })
    .eq("twilio_sid", sid);

  if (error) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }

  return NextResponse.json({ success: true });
}
