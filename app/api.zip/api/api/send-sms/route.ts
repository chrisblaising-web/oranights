import { NextResponse } from "next/server";
import twilio from "twilio";
import { createClient } from "@supabase/supabase-js";

type SmsPayload = {
  guestId?: number | null;
  campaign?: string;
  audience?: string;
  phone?: string;
  name?: string | null;
  message?: string;
  messageTemplate?: string;
};

function createSupabaseAdmin() {
  const supabaseUrl =
    process.env.NEXT_PUBLIC_SUPABASE_URL;

  const serviceKey =
    process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!supabaseUrl || !serviceKey) {
    return null;
  }

  return createClient(supabaseUrl, serviceKey, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  });
}

/**
 * Converts Canadian and US phone numbers to Twilio's E.164 format.
 *
 * Examples:
 * 4385551234       -> +14385551234
 * (438) 555-1234   -> +14385551234
 * 1 438 555 1234   -> +14385551234
 * +14385551234     -> +14385551234
 */
function normalizePhoneNumber(
  value?: string
): string {
  const original = value?.trim() || "";

  if (!original) {
    return "";
  }

  const digits = original.replace(/\D/g, "");

  if (!digits) {
    return "";
  }

  // Canadian or US number without country code
  if (digits.length === 10) {
    return `+1${digits}`;
  }

  // Canadian or US number with country code
  if (
    digits.length === 11 &&
    digits.startsWith("1")
  ) {
    return `+${digits}`;
  }

  // International number already beginning with +
  if (original.startsWith("+")) {
    return `+${digits}`;
  }

  // International number entered with country code but no +
  if (
    digits.length >= 8 &&
    digits.length <= 15
  ) {
    return `+${digits}`;
  }

  return original;
}

export async function POST(req: Request) {
  let payload: SmsPayload = {};

  try {
    payload = (await req.json()) as SmsPayload;

    const campaign =
      payload.campaign?.trim();

    const audience =
      payload.audience?.trim() ||
      "Single Guest";

    const phone = normalizePhoneNumber(
      payload.phone
    );

    const message =
      payload.message?.trim();

    if (!campaign || !phone || !message) {
      return NextResponse.json(
        {
          success: false,
          error:
            "Campaign, phone and message are required.",
        },
        { status: 400 }
      );
    }

    if (!/^\+[1-9]\d{7,14}$/.test(phone)) {
      return NextResponse.json(
        {
          success: false,
          error:
            "The phone number is invalid. Enter a Canadian number such as 4385551234.",
        },
        { status: 400 }
      );
    }

    if (message.length > 320) {
      return NextResponse.json(
        {
          success: false,
          error:
            "The SMS message cannot exceed 320 characters.",
        },
        { status: 400 }
      );
    }

    const sid =
      process.env.TWILIO_ACCOUNT_SID;

    const token =
      process.env.TWILIO_AUTH_TOKEN;

    const from =
      process.env.TWILIO_PHONE_NUMBER;

    if (!sid || !token || !from) {
      throw new Error(
        "Twilio environment variables are missing."
      );
    }

    const client = twilio(sid, token);

    const sms = await client.messages.create({
      body: message,
      from,
      to: phone,
    });

    const admin = createSupabaseAdmin();

    if (admin) {
      const { error: logError } = await admin
        .from("sms_logs")
        .insert({
          guest_id: payload.guestId ?? null,
          campaign,
          audience,
          phone,
          message,
          status: sms.status || "sent",
          twilio_sid: sms.sid,
        });

      if (logError) {
        console.error(
          "SMS sent but logging failed:",
          {
            message: logError.message,
            details: logError.details,
            hint: logError.hint,
            code: logError.code,
          }
        );
      }
    } else {
      console.warn(
        "SMS sent, but Supabase logging was skipped because admin environment variables are missing."
      );
    }

    return NextResponse.json({
      success: true,
      sid: sms.sid,
      status: sms.status,
      phone,
      recipientName:
        payload.name?.trim() || null,
    });
  } catch (error) {
    const errorMessage =
      error instanceof Error
        ? error.message
        : "Unknown SMS error";

    console.error("SMS route error:", error);

    const admin = createSupabaseAdmin();

    if (admin) {
      const normalizedPhone =
        normalizePhoneNumber(payload.phone) ||
        null;

      const { error: logError } = await admin
        .from("sms_logs")
        .insert({
          guest_id: payload.guestId ?? null,
          campaign:
            payload.campaign?.trim() ||
            "Untitled campaign",
          audience:
            payload.audience?.trim() ||
            "Single Guest",
          phone: normalizedPhone,
          message:
            payload.message?.trim() || null,
          status: "failed",
          error_message: errorMessage,
        });

      if (logError) {
        console.error(
          "Failed SMS logging also failed:",
          {
            message: logError.message,
            details: logError.details,
            hint: logError.hint,
            code: logError.code,
          }
        );
      }
    }

    return NextResponse.json(
      {
        success: false,
        error: errorMessage,
      },
      { status: 500 }
    );
  }
}