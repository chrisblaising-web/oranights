import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function createSupabaseAdmin() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!url || !key) return null;

  return createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

export async function POST(req: Request) {
  try {
    const form = await req.formData();
    const sid = String(form.get("MessageSid") || "").trim();
    const status = String(form.get("MessageStatus") || "").trim();
    const errorCode = String(form.get("ErrorCode") || "").trim();
    const errorMessage = String(form.get("ErrorMessage") || "").trim();

    if (!sid || !status) {
      return NextResponse.json(
        { success: false, error: "MessageSid and MessageStatus are required." },
        { status: 400 }
      );
    }

    const admin = createSupabaseAdmin();
    if (!admin) {
      return NextResponse.json(
        { success: false, error: "Supabase admin environment variables are missing." },
        { status: 500 }
      );
    }

    const now = new Date().toISOString();
    const update = {
      status,
      error_message: errorMessage || (errorCode ? `Twilio error ${errorCode}` : null),
      twilio_error_code: errorCode || null,
      delivered_at: status === "delivered" ? now : null,
      updated_at: now,
    };

    const [messageResult, logResult] = await Promise.all([
      admin.from("sms_messages").update(update).eq("twilio_sid", sid),
      admin.from("sms_logs").update(update).eq("twilio_sid", sid),
    ]);

    if (messageResult.error && logResult.error) {
      console.error("Twilio status update failed:", {
        smsMessages: messageResult.error,
        smsLogs: logResult.error,
      });

      return NextResponse.json(
        { success: false, error: "Unable to update SMS delivery status." },
        { status: 500 }
      );
    }

    if (messageResult.error) {
      console.error("sms_messages status update failed:", messageResult.error);
    }

    if (logResult.error) {
      console.error("sms_logs status update failed:", logResult.error);
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown callback error";
    console.error("Twilio callback error:", error);

    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}

export async function GET() {
  return NextResponse.json({
    success: true,
    route: "/api/twilio/status",
    message: "Twilio delivery status webhook is active.",
  });
}
