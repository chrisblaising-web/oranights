import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function createSupabaseAdmin() {
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

    if (!supabaseUrl || !serviceRoleKey) {
        return null;
    }

    return createClient(supabaseUrl, serviceRoleKey, {
        auth: {
            persistSession: false,
            autoRefreshToken: false,
        },
    });
}

function normalizePhone(phone: string) {
    const cleaned = phone.replace(/[^\d+]/g, "");

    if (cleaned.startsWith("+")) {
        return cleaned;
    }

    const digits = cleaned.replace(/\D/g, "");

    if (digits.length === 10) {
        return `+1${digits}`;
    }

    if (digits.length === 11 && digits.startsWith("1")) {
        return `+${digits}`;
    }

    return cleaned;
}

function getPhoneVariants(phone: string) {
    const normalizedPhone = normalizePhone(phone);
    const digitsOnly = normalizedPhone.replace(/\D/g, "");

    const variants = new Set<string>();

    variants.add(normalizedPhone);
    variants.add(digitsOnly);

    if (digitsOnly.length === 11 && digitsOnly.startsWith("1")) {
        variants.add(digitsOnly.substring(1));
        variants.add(`+${digitsOnly}`);
    }

    if (digitsOnly.length === 10) {
        variants.add(`+1${digitsOnly}`);
        variants.add(`1${digitsOnly}`);
    }

    return Array.from(variants);
}

function createEmptyTwimlResponse() {
    return new NextResponse(
        `<?xml version="1.0" encoding="UTF-8"?><Response></Response>`,
        {
            status: 200,
            headers: {
                "Content-Type": "text/xml",
            },
        }
    );
}

export async function POST(request: NextRequest) {
    try {
        const supabase = createSupabaseAdmin();

        if (!supabase) {
            console.error(
                "Missing NEXT_PUBLIC_SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY."
            );

            return new NextResponse("Server configuration error.", {
                status: 500,
            });
        }

        const formData = await request.formData();

        const from = String(formData.get("From") || "").trim();
        const to = String(formData.get("To") || "").trim();
        const body = String(formData.get("Body") || "").trim();
        const messageSid = String(formData.get("MessageSid") || "").trim();
        const smsStatus = String(
            formData.get("SmsStatus") || "received"
        ).trim();

        const numMedia = Number(formData.get("NumMedia") || 0);

        if (!from) {
            console.error("Inbound SMS webhook did not include a From number.");

            return createEmptyTwimlResponse();
        }

        if (!body && numMedia === 0) {
            console.error("Inbound SMS webhook did not include a message body.");

            return createEmptyTwimlResponse();
        }

        const normalizedPhone = normalizePhone(from);
        const phoneVariants = getPhoneVariants(from);

        let guestId: number | null = null;
        let guestName: string | null = null;

        const { data: matchingGuests, error: guestLookupError } = await supabase
            .from("guests")
            .select("id, name, phone")
            .in("phone", phoneVariants)
            .limit(1);

        if (guestLookupError) {
            console.error("Guest lookup error:", guestLookupError);
        }

        if (matchingGuests && matchingGuests.length > 0) {
            const guest = matchingGuests[0];

            guestId = guest.id;
            guestName = guest.name || null;
        }

        let storedMessage = body;

        if (!storedMessage && numMedia > 0) {
            storedMessage =
                numMedia === 1
                    ? "[Guest sent one media attachment]"
                    : `[Guest sent ${numMedia} media attachments]`;
        }

        const messageRecord = {
            guest_id: guestId,
            guest_name: guestName,
            phone: normalizedPhone,
            direction: "inbound",
            message: storedMessage,
            status: smsStatus || "received",
            twilio_sid: messageSid || null,
            twilio_error_code: null,
            error_message: null,
            is_read: false,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
            delivered_at: null,
        };

        const { error: insertError } = await supabase
            .from("sms_messages")
            .insert(messageRecord);

        if (insertError) {
            const isDuplicateMessage =
                insertError.code === "23505" &&
                insertError.message
                    .toLowerCase()
                    .includes("twilio");

            if (isDuplicateMessage) {
                console.log(
                    `Inbound SMS ${messageSid} was already saved.`
                );

                return createEmptyTwimlResponse();
            }

            console.error("Inbound SMS insert error:", insertError);

            return new NextResponse("Unable to save inbound SMS.", {
                status: 500,
            });
        }

        console.log("Inbound SMS saved:", {
            from: normalizedPhone,
            to,
            guestId,
            guestName,
            messageSid,
            status: smsStatus,
        });

        return createEmptyTwimlResponse();
    } catch (error) {
        console.error("Unexpected inbound SMS webhook error:", error);

        return new NextResponse("Unexpected server error.", {
            status: 500,
        });
    }
}

export async function GET() {
    return NextResponse.json({
        success: true,
        route: "/api/twilio/inbound",
        message: "Twilio inbound SMS webhook is active.",
    });
}