"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import Sidebar from "@/components/Sidebar";
import { supabase } from "@/lib/supabase";

type RecipientMode = "individual" | "manual" | "group";

type Guest = {
  id: number;
  name: string | null;
  phone: string | null;
  tag: string | null;
  vip_level: string | null;
};

type SmsLog = {
  id: number;
  guest_id: number | null;
  campaign: string | null;
  audience: string | null;
  phone: string | null;
  message: string | null;
  status: string | null;
  created_at: string;
};

const GROUP_OPTIONS = [
  "All Guests",
  "VIP",
  "BLACK",
  "New Guest",
  "Regular Client",
  "High Spender",
  "Influencer",
  "Birthday",
  "Artist",
  "Promoter",
];

function personalizeMessage(
  template: string,
  fullName: string | null
) {
  const firstName =
    fullName?.trim().split(/\s+/)[0] || "Guest";

  return template.replaceAll(
    "{{name}}",
    firstName
  );
}

export default function SMSPage() {
  const [title, setTitle] = useState("");
  const [message, setMessage] = useState("");

  const [recipientMode, setRecipientMode] =
    useState<RecipientMode>("individual");

  const [selectedGuestId, setSelectedGuestId] =
    useState("");

  const [selectedGroup, setSelectedGroup] =
    useState("");

  const [manualName, setManualName] =
    useState("");

  const [manualPhone, setManualPhone] =
    useState("");

  const [guests, setGuests] = useState<Guest[]>([]);
  const [logs, setLogs] = useState<SmsLog[]>([]);

  const [status, setStatus] = useState("");
  const [sending, setSending] = useState(false);
  const [loadingGuests, setLoadingGuests] =
    useState(true);

  async function loadGuests() {
    setLoadingGuests(true);

    const { data, error } = await supabase
      .from("guests")
      .select("id,name,phone,tag,vip_level")
      .order("name", {
        ascending: true,
      });

    if (error) {
      console.error("Guest loading error:", error);
      setStatus(
        `Guests could not be loaded: ${error.message}`
      );
      setLoadingGuests(false);
      return;
    }

    setGuests((data as Guest[]) ?? []);
    setLoadingGuests(false);
  }

  async function loadLogs() {
    const { data, error } = await supabase
      .from("sms_logs")
      .select(
        "id,guest_id,campaign,audience,phone,message,status,created_at"
      )
      .order("created_at", {
        ascending: false,
      })
      .limit(50);

    if (error) {
      console.error("SMS log error:", error);
      return;
    }

    setLogs((data as SmsLog[]) ?? []);
  }

  useEffect(() => {
    void loadGuests();
    void loadLogs();
  }, []);

  const selectedGuest = useMemo(() => {
    return guests.find(
      (guest) =>
        String(guest.id) === selectedGuestId
    );
  }, [guests, selectedGuestId]);

  const groupGuests = useMemo(() => {
    if (!selectedGroup) {
      return [];
    }

    return guests.filter((guest) => {
      if (!guest.phone?.trim()) {
        return false;
      }

      if (selectedGroup === "All Guests") {
        return true;
      }

      if (
        selectedGroup === "VIP" ||
        selectedGroup === "BLACK"
      ) {
        return (
          guest.vip_level === selectedGroup
        );
      }

      return guest.tag === selectedGroup;
    });
  }, [guests, selectedGroup]);

  const recipients = useMemo(() => {
    if (recipientMode === "individual") {
      if (!selectedGuest?.phone?.trim()) {
        return [];
      }

      return [selectedGuest];
    }

    if (recipientMode === "manual") {
      if (!manualPhone.trim()) {
        return [];
      }

      return [
        {
          id: null,
          name: manualName.trim() || "Manual Guest",
          phone: manualPhone.trim(),
          tag: null,
          vip_level: null,
        },
      ];
    }

    return groupGuests;
  }, [
    recipientMode,
    selectedGuest,
    manualName,
    manualPhone,
    groupGuests,
  ]);

  const previewName =
    recipients[0]?.name || "Guest";

  const messagePreview = useMemo(() => {
    return personalizeMessage(
      message,
      previewName
    );
  }, [message, previewName]);

  async function sendSMS() {
    if (!title.trim()) {
      setStatus(
        "Please enter a campaign name."
      );
      return;
    }

    if (!message.trim()) {
      setStatus("Please write your SMS message.");
      return;
    }

    if (
      recipientMode === "individual" &&
      !selectedGuest
    ) {
      setStatus("Please select one guest.");
      return;
    }

    if (
      recipientMode === "individual" &&
      !selectedGuest?.phone?.trim()
    ) {
      setStatus(
        "This guest does not have a phone number."
      );
      return;
    }

    if (
      recipientMode === "group" &&
      !selectedGroup
    ) {
      setStatus("Please select a guest group.");
      return;
    }

    if (recipientMode === "manual") {
      const normalizedPhone =
        manualPhone.replace(/[\s()-]/g, "");

      if (!manualPhone.trim()) {
        setStatus("Please enter a phone number.");
        return;
      }

      if (!/^\+\d{8,15}$/.test(normalizedPhone)) {
        setStatus(
          "Enter a valid phone number with country code, such as +15145551234."
        );
        return;
      }
    }

    if (recipients.length === 0) {
      setStatus(
        "No guests with phone numbers were found."
      );
      return;
    }

    setSending(true);
    setStatus(
      recipients.length === 1
        ? "Sending SMS..."
        : `Sending to ${recipients.length} guests...`
    );

    let sentCount = 0;
    let failedCount = 0;

    try {
      for (const recipient of recipients) {
        try {
          const personalizedMessage =
            personalizeMessage(
              message.trim(),
              recipient.name
            );

          const response = await fetch(
            "/api/send-sms",
            {
              method: "POST",
              headers: {
                "Content-Type":
                  "application/json",
              },
              body: JSON.stringify({
                guestId: recipient.id,
                campaign: title.trim(),
                audience:
                  recipientMode === "individual"
                    ? "Single Guest"
                    : recipientMode === "manual"
                      ? "Manual Number"
                      : selectedGroup,
                phone:
                  recipient.phone
                    ?.replace(/[\s()-]/g, ""),
                name: recipient.name,
                message:
                  personalizedMessage,
                messageTemplate:
                  message.trim(),
              }),
            }
          );

          const data =
            await response.json();

          if (
            !response.ok ||
            !data.success
          ) {
            throw new Error(
              data.error ||
              "SMS failed"
            );
          }

          sentCount++;
        } catch (error) {
          failedCount++;

          console.error(
            `SMS failed for ${recipient.name}:`,
            error
          );
        }
      }

      if (failedCount === 0) {
        setStatus(
          `${sentCount} SMS ${sentCount === 1
            ? "message"
            : "messages"
          } sent successfully ✅`
        );

        setMessage("");
      } else {
        setStatus(
          `${sentCount} sent, ${failedCount} failed.`
        );
      }

      await loadLogs();
    } catch (error) {
      setStatus(
        error instanceof Error
          ? `SMS failed: ${error.message}`
          : "SMS failed."
      );
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="flex min-h-screen bg-black text-white">
      <Sidebar />

      <main className="flex-1 p-6 md:p-10">
        <h1 className="text-4xl font-bold">
          SMS Campaigns
        </h1>

        <p className="mt-2 text-zinc-400">
          Send a message to one saved guest, one manual number,
          or an entire guest group.
        </p>

        <div className="mt-10 grid gap-8 xl:grid-cols-2">
          <section className="space-y-6 rounded-xl bg-zinc-900 p-6">
            <div>
              <label
                htmlFor="campaign-name"
                className="mb-2 block text-sm text-zinc-400"
              >
                Campaign name
              </label>

              <input
                id="campaign-name"
                placeholder="Example: Friday VIP Reminder"
                value={title}
                onChange={(event) =>
                  setTitle(
                    event.target.value
                  )
                }
                className="w-full rounded bg-zinc-800 p-4 outline-none ring-blue-600 focus:ring-2"
              />
            </div>

            <div>
              <h2 className="text-lg font-bold">
                Who do you want to message?
              </h2>

              <div className="mt-4 grid gap-3 md:grid-cols-3">
                <button
                  type="button"
                  onClick={() => {
                    setRecipientMode(
                      "individual"
                    );
                    setSelectedGroup("");
                    setStatus("");
                  }}
                  className={`rounded-lg border p-4 text-left transition ${recipientMode ===
                    "individual"
                    ? "border-blue-500 bg-blue-950/40"
                    : "border-zinc-700 bg-zinc-800 hover:border-zinc-500"
                    }`}
                >
                  <p className="font-semibold">
                    One Guest
                  </p>

                  <p className="mt-1 text-sm text-zinc-400">
                    Select one person and
                    view their phone number.
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setRecipientMode(
                      "manual"
                    );
                    setSelectedGuestId("");
                    setSelectedGroup("");
                    setStatus("");
                  }}
                  className={`rounded-lg border p-4 text-left transition ${recipientMode ===
                    "manual"
                    ? "border-blue-500 bg-blue-950/40"
                    : "border-zinc-700 bg-zinc-800 hover:border-zinc-500"
                    }`}
                >
                  <p className="font-semibold">
                    Manual Number
                  </p>

                  <p className="mt-1 text-sm text-zinc-400">
                    Enter one guest and phone number manually.
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setRecipientMode(
                      "group"
                    );
                    setSelectedGuestId(
                      ""
                    );
                    setStatus("");
                  }}
                  className={`rounded-lg border p-4 text-left transition ${recipientMode ===
                    "group"
                    ? "border-blue-500 bg-blue-950/40"
                    : "border-zinc-700 bg-zinc-800 hover:border-zinc-500"
                    }`}
                >
                  <p className="font-semibold">
                    Guest Group
                  </p>

                  <p className="mt-1 text-sm text-zinc-400">
                    Send to guests sharing
                    a tag or VIP level.
                  </p>
                </button>
              </div>
            </div>

            {recipientMode ===
              "individual" && (
                <div>
                  <label
                    htmlFor="guest"
                    className="mb-2 block text-sm text-zinc-400"
                  >
                    Select guest
                  </label>

                  <select
                    id="guest"
                    value={
                      selectedGuestId
                    }
                    onChange={(event) => {
                      setSelectedGuestId(
                        event.target.value
                      );
                      setStatus("");
                    }}
                    disabled={
                      loadingGuests
                    }
                    className="w-full rounded bg-zinc-800 p-4 outline-none ring-blue-600 focus:ring-2 disabled:opacity-50"
                  >
                    <option value="">
                      {loadingGuests
                        ? "Loading guests..."
                        : "Choose a guest"}
                    </option>

                    {guests.map(
                      (guest) => (
                        <option
                          key={
                            guest.id
                          }
                          value={
                            guest.id
                          }
                        >
                          {guest.name ||
                            "Unnamed guest"}{" "}
                          —{" "}
                          {guest.phone ||
                            "No phone number"}
                        </option>
                      )
                    )}
                  </select>

                  {selectedGuest && (
                    <div className="mt-4 rounded-lg border border-zinc-700 bg-black p-4">
                      <p className="text-sm text-zinc-400">
                        Selected recipient
                      </p>

                      <p className="mt-1 text-lg font-semibold">
                        {selectedGuest.name ||
                          "Unnamed guest"}
                      </p>

                      <div className="mt-3 grid gap-3 sm:grid-cols-2">
                        <div>
                          <p className="text-xs uppercase text-zinc-500">
                            Phone
                          </p>

                          <p className="mt-1 text-zinc-200">
                            {selectedGuest.phone ||
                              "No phone number"}
                          </p>
                        </div>

                        <div>
                          <p className="text-xs uppercase text-zinc-500">
                            Group
                          </p>

                          <p className="mt-1 text-zinc-200">
                            {selectedGuest.tag ||
                              selectedGuest.vip_level ||
                              "No group"}
                          </p>
                        </div>
                      </div>

                      {!selectedGuest.phone && (
                        <p className="mt-4 rounded bg-red-950/40 p-3 text-sm text-red-300">
                          Add a phone
                          number to this
                          guest before
                          sending an SMS.
                        </p>
                      )}
                    </div>
                  )}
                </div>
              )}

            {recipientMode === "manual" && (
              <div className="space-y-4">
                <div>
                  <label
                    htmlFor="manual-name"
                    className="mb-2 block text-sm text-zinc-400"
                  >
                    Guest name
                  </label>

                  <input
                    id="manual-name"
                    type="text"
                    value={manualName}
                    onChange={(event) => {
                      setManualName(
                        event.target.value
                      );
                      setStatus("");
                    }}
                    placeholder="Example: John Doe"
                    className="w-full rounded bg-zinc-800 p-4 outline-none ring-blue-600 focus:ring-2"
                  />
                </div>

                <div>
                  <label
                    htmlFor="manual-phone"
                    className="mb-2 block text-sm text-zinc-400"
                  >
                    Phone number
                  </label>

                  <input
                    id="manual-phone"
                    type="tel"
                    value={manualPhone}
                    onChange={(event) => {
                      setManualPhone(
                        event.target.value
                      );
                      setStatus("");
                    }}
                    placeholder="+1 514 555 1234"
                    className="w-full rounded bg-zinc-800 p-4 outline-none ring-blue-600 focus:ring-2"
                  />

                  <p className="mt-2 text-xs text-zinc-500">
                    Include the country code, for example +1 for Canada.
                  </p>
                </div>

                {manualPhone.trim() && (
                  <div className="rounded-lg border border-zinc-700 bg-black p-4">
                    <p className="text-sm text-zinc-400">
                      Manual recipient
                    </p>

                    <p className="mt-1 text-lg font-semibold">
                      {manualName.trim() ||
                        "Unnamed guest"}
                    </p>

                    <p className="mt-2 text-zinc-300">
                      {manualPhone}
                    </p>

                    <p className="mt-3 text-xs text-amber-300">
                      This sends one SMS without adding the person to your guest database.
                    </p>
                  </div>
                )}
              </div>
            )}

            {recipientMode === "group" && (
              <div>
                <label
                  htmlFor="guest-group"
                  className="mb-2 block text-sm text-zinc-400"
                >
                  Select guest group
                </label>

                <select
                  id="guest-group"
                  value={selectedGroup}
                  onChange={(event) => {
                    setSelectedGroup(
                      event.target.value
                    );
                    setStatus("");
                  }}
                  disabled={
                    loadingGuests
                  }
                  className="w-full rounded bg-zinc-800 p-4 outline-none ring-blue-600 focus:ring-2 disabled:opacity-50"
                >
                  <option value="">
                    Choose a group
                  </option>

                  {GROUP_OPTIONS.map(
                    (group) => (
                      <option
                        key={
                          group
                        }
                        value={
                          group
                        }
                      >
                        {group}
                      </option>
                    )
                  )}
                </select>

                {selectedGroup && (
                  <div className="mt-4 rounded-lg border border-zinc-700 bg-black p-4">
                    <div className="flex items-center justify-between gap-4">
                      <div>
                        <p className="text-sm text-zinc-400">
                          Selected
                          group
                        </p>

                        <p className="mt-1 text-lg font-semibold">
                          {
                            selectedGroup
                          }
                        </p>
                      </div>

                      <span className="rounded-full bg-blue-950 px-3 py-1 text-sm text-blue-300">
                        {
                          groupGuests.length
                        }{" "}
                        recipients
                      </span>
                    </div>

                    {groupGuests.length >
                      0 ? (
                      <div className="mt-4 max-h-56 space-y-2 overflow-y-auto">
                        {groupGuests.map(
                          (
                            guest
                          ) => (
                            <div
                              key={
                                guest.id
                              }
                              className="flex flex-col justify-between gap-1 rounded bg-zinc-900 px-3 py-3 sm:flex-row sm:items-center"
                            >
                              <span className="font-medium">
                                {guest.name ||
                                  "Unnamed guest"}
                              </span>

                              <span className="text-sm text-zinc-400">
                                {
                                  guest.phone
                                }
                              </span>
                            </div>
                          )
                        )}
                      </div>
                    ) : (
                      <p className="mt-4 text-sm text-amber-300">
                        No guests in
                        this group have
                        phone numbers.
                      </p>
                    )}
                  </div>
                )}
              </div>
            )}

            <div>
              <label
                htmlFor="message"
                className="mb-2 block text-sm text-zinc-400"
              >
                SMS message
              </label>

              <textarea
                id="message"
                placeholder="Hi {{name}}, Ora Nights is back this Friday..."
                value={message}
                onChange={(event) =>
                  setMessage(
                    event.target.value
                  )
                }
                maxLength={320}
                className="h-40 w-full rounded bg-zinc-800 p-4 outline-none ring-blue-600 focus:ring-2"
              />

              <div className="mt-2 flex flex-col gap-2 text-xs text-zinc-500 sm:flex-row sm:items-center sm:justify-between">
                <p>
                  Use {"{{name}}"} to insert each guest&apos;s first name automatically.
                </p>

                <p>
                  {message.length}/320
                </p>
              </div>

              {message.trim() && (
                <div className="mt-4 rounded-lg border border-zinc-700 bg-black p-4">
                  <p className="text-xs uppercase tracking-wide text-zinc-500">
                    Personalized preview
                  </p>

                  <p className="mt-2 whitespace-pre-wrap text-sm text-zinc-200">
                    {messagePreview}
                  </p>

                  {recipients.length > 1 && (
                    <p className="mt-3 text-xs text-blue-300">
                      Each guest will receive this message with their own first name.
                    </p>
                  )}
                </div>
              )}
            </div>

            <button
              type="button"
              onClick={sendSMS}
              disabled={
                sending ||
                recipients.length === 0
              }
              className="rounded bg-white px-6 py-3 font-medium text-black transition hover:bg-zinc-200 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {sending
                ? "Sending..."
                : recipients.length > 1
                  ? `Send to ${recipients.length} Guests`
                  : "Send SMS"}
            </button>

            {status && (
              <p className="rounded-lg bg-zinc-800 p-3 text-sm text-zinc-300">
                {status}
              </p>
            )}
          </section>

          <section className="rounded-xl bg-zinc-900 p-6">
            <h2 className="mb-5 text-2xl font-bold">
              Recent SMS History
            </h2>

            <div className="max-h-[750px] space-y-4 overflow-y-auto">
              {logs.map((log) => (
                <article
                  key={log.id}
                  className="border-b border-zinc-700 pb-4"
                >
                  <div className="flex justify-between gap-4">
                    <strong>
                      {log.campaign ||
                        "Untitled campaign"}
                    </strong>

                    <span
                      className={
                        log.status ===
                          "sent"
                          ? "text-green-400"
                          : "text-red-400"
                      }
                    >
                      {log.status ||
                        "unknown"}
                    </span>
                  </div>

                  <p className="mt-1 text-sm text-zinc-400">
                    {log.phone ||
                      "No phone"}{" "}
                    ·{" "}
                    {log.audience ||
                      "Single Guest"}
                  </p>

                  <p className="mt-2 whitespace-pre-wrap">
                    {log.message}
                  </p>

                  <div className="mt-2 flex flex-wrap items-center justify-between gap-3">
                    <p className="text-xs text-zinc-500">
                      {new Date(log.created_at).toLocaleString()}
                    </p>

                    {log.guest_id && (
                      <Link
                        href={`/guests/${log.guest_id}`}
                        className="text-xs font-medium text-blue-400 hover:text-blue-300"
                      >
                        View guest profile
                      </Link>
                    )}
                  </div>
                </article>
              ))}

              {logs.length === 0 && (
                <p className="text-zinc-500">
                  No SMS history found.
                </p>
              )}
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}