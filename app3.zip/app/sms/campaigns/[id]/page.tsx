"use client";

import { useEffect, useMemo, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Sidebar from "@/components/Sidebar";
import { supabase } from "@/lib/supabase";

type Campaign = {
  id: number;
  campaign_name: string;
  audience: string | null;
  message_template: string | null;
  total_recipients: number | null;
  sent_count: number | null;
  failed_count: number | null;
  status: string | null;
  created_at: string;
  completed_at: string | null;
};

type SmsLog = {
  id: number;
  guest_name: string | null;
  phone: string | null;
  message: string | null;
  status: string | null;
  error_message: string | null;
  created_at: string;
};

export default function SmsCampaignDetailsPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const campaignId = Number(params.id);

  const [campaign, setCampaign] = useState<Campaign | null>(null);
  const [logs, setLogs] = useState<SmsLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    async function loadCampaign() {
      setLoading(true);
      setError("");

      const { data: campaignData, error: campaignError } = await supabase
        .from("sms_campaigns")
        .select(
          "id,campaign_name,audience,message_template,total_recipients,sent_count,failed_count,status,created_at,completed_at"
        )
        .eq("id", campaignId)
        .single();

      if (campaignError) {
        setError(campaignError.message);
        setLoading(false);
        return;
      }

      const { data: logData, error: logError } = await supabase
        .from("sms_logs")
        .select("id,guest_name,phone,message,status,error_message,created_at")
        .eq("campaign_id", campaignId)
        .order("created_at", { ascending: false });

      if (logError) {
        setError(logError.message);
        setLoading(false);
        return;
      }

      setCampaign(campaignData as Campaign);
      setLogs((logData as SmsLog[]) ?? []);
      setLoading(false);
    }

    if (Number.isFinite(campaignId)) {
      void loadCampaign();
    } else {
      setError("Invalid campaign ID.");
      setLoading(false);
    }
  }, [campaignId]);

  const summary = useMemo(() => {
    const delivered = logs.filter(
      (log) => log.status?.toLowerCase() === "delivered"
    ).length;

    const failed = logs.filter((log) =>
      ["failed", "undelivered"].includes(log.status?.toLowerCase() || "")
    ).length;

    const pending = logs.filter((log) =>
      ["sending", "accepted", "queued", "sent"].includes(
        log.status?.toLowerCase() || ""
      )
    ).length;

    return { delivered, failed, pending };
  }, [logs]);

  return (
    <div className="flex min-h-screen bg-black text-white">
      <Sidebar />

      <main className="flex-1 p-6 md:p-10">
        <button
          type="button"
          onClick={() => router.push("/sms")}
          className="mb-6 rounded bg-zinc-800 px-4 py-2 text-sm hover:bg-zinc-700"
        >
          Back to SMS
        </button>

        {loading && <p className="text-zinc-400">Loading campaign...</p>}

        {error && (
          <p className="rounded bg-red-950/40 p-4 text-red-300">{error}</p>
        )}

        {!loading && !error && campaign && (
          <>
            <h1 className="text-4xl font-bold">{campaign.campaign_name}</h1>

            <p className="mt-2 text-zinc-400">
              {campaign.audience || "Unknown audience"} · Created {" "}
              {new Date(campaign.created_at).toLocaleString()}
            </p>

            <div className="mt-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
              <div className="rounded-xl bg-zinc-900 p-5">
                <p className="text-sm text-zinc-400">Recipients</p>
                <p className="mt-2 text-3xl font-bold">
                  {campaign.total_recipients ?? logs.length}
                </p>
              </div>

              <div className="rounded-xl bg-zinc-900 p-5">
                <p className="text-sm text-zinc-400">Delivered</p>
                <p className="mt-2 text-3xl font-bold text-green-400">
                  {summary.delivered}
                </p>
              </div>

              <div className="rounded-xl bg-zinc-900 p-5">
                <p className="text-sm text-zinc-400">Failed</p>
                <p className="mt-2 text-3xl font-bold text-red-400">
                  {summary.failed}
                </p>
              </div>

              <div className="rounded-xl bg-zinc-900 p-5">
                <p className="text-sm text-zinc-400">Pending</p>
                <p className="mt-2 text-3xl font-bold text-amber-300">
                  {summary.pending}
                </p>
              </div>
            </div>

            <section className="mt-8 rounded-xl bg-zinc-900 p-6">
              <h2 className="text-2xl font-bold">Message</h2>
              <p className="mt-4 whitespace-pre-wrap text-zinc-300">
                {campaign.message_template || "No message template saved."}
              </p>
            </section>

            <section className="mt-8 rounded-xl bg-zinc-900 p-6">
              <h2 className="text-2xl font-bold">Recipients</h2>

              <div className="mt-5 space-y-4">
                {logs.map((log) => {
                  const currentStatus = log.status?.toLowerCase() || "unknown";

                  const statusClass =
                    currentStatus === "delivered"
                      ? "text-green-400"
                      : ["failed", "undelivered"].includes(currentStatus)
                        ? "text-red-400"
                        : "text-amber-300";

                  return (
                    <article
                      key={log.id}
                      className="rounded-lg border border-zinc-700 bg-black p-4"
                    >
                      <div className="flex flex-col justify-between gap-3 sm:flex-row">
                        <div>
                          <p className="font-semibold">
                            {log.guest_name || "Unknown guest"}
                          </p>
                          <p className="mt-1 text-sm text-zinc-400">
                            {log.phone || "No phone number"}
                          </p>
                        </div>

                        <span className={`capitalize ${statusClass}`}>
                          {currentStatus}
                        </span>
                      </div>

                      {log.error_message && (
                        <p className="mt-3 rounded bg-red-950/40 p-3 text-sm text-red-300">
                          {log.error_message}
                        </p>
                      )}

                      <p className="mt-3 text-xs text-zinc-500">
                        {new Date(log.created_at).toLocaleString()}
                      </p>
                    </article>
                  );
                })}

                {logs.length === 0 && (
                  <p className="text-zinc-500">No recipient logs found.</p>
                )}
              </div>
            </section>
          </>
        )}
      </main>
    </div>
  );
}
