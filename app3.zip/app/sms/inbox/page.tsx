"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import Sidebar from "@/components/Sidebar";
import { supabase } from "@/lib/supabase";
import ChatWindow from "./_components/ChatWindow";
import ConversationList from "./_components/ConversationList";
import ReplyComposer from "./_components/ReplyComposer";
import { buildConversations } from "./_components/chatUtils";
import { SmsMessage } from "./_components/types";

const MESSAGE_FIELDS = `
  id,
  guest_id,
  guest_name,
  phone,
  direction,
  message,
  status,
  twilio_sid,
  twilio_error_code,
  error_message,
  is_read,
  created_at,
  updated_at,
  delivered_at
`;

type Notice = {
  tone: "success" | "warning" | "error";
  message: string;
} | null;

export default function SmsInboxPage() {
  const [messages, setMessages] = useState<SmsMessage[]>([]);
  const [selectedPhone, setSelectedPhone] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [replyMessage, setReplyMessage] = useState("");
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [notice, setNotice] = useState<Notice>(null);
  const [mobileConversationOpen, setMobileConversationOpen] = useState(false);

  const conversations = useMemo(() => buildConversations(messages), [messages]);

  const selectedConversation = useMemo(
    () => conversations.find((conversation) => conversation.phone === selectedPhone) || null,
    [conversations, selectedPhone]
  );

  const totalUnread = useMemo(
    () => conversations.reduce((total, conversation) => total + conversation.unreadCount, 0),
    [conversations]
  );

  const loadMessages = useCallback(async (showLoading = false) => {
    if (showLoading) setLoading(true);

    const { data, error } = await supabase
      .from("sms_messages")
      .select(MESSAGE_FIELDS)
      .order("created_at", { ascending: true });

    if (error) {
      console.error("Unable to load SMS inbox:", error);
      setNotice({ tone: "error", message: `Unable to load inbox: ${error.message}` });
      setLoading(false);
      return;
    }

    const loaded = (data || []) as SmsMessage[];
    setMessages(loaded);
    setLoading(false);
    setSelectedPhone((currentPhone) => currentPhone || loaded.at(-1)?.phone || null);
  }, []);

  useEffect(() => {
    void loadMessages(true);

    const refreshInterval = window.setInterval(() => {
      void loadMessages(false);
    }, 10000);

    const channel = supabase
      .channel("sms-inbox-realtime")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "sms_messages" },
        () => void loadMessages(false)
      )
      .subscribe();

    return () => {
      window.clearInterval(refreshInterval);
      void supabase.removeChannel(channel);
    };
  }, [loadMessages]);

  async function selectConversation(phone: string) {
    setSelectedPhone(phone);
    setMobileConversationOpen(true);
    setNotice(null);

    const conversation = conversations.find((item) => item.phone === phone);
    if (!conversation?.unreadCount) return;

    const unreadIds = conversation.messages
      .filter((message) => message.direction === "inbound" && !message.is_read)
      .map((message) => message.id);

    if (!unreadIds.length) return;

    setMessages((currentMessages) =>
      currentMessages.map((message) =>
        unreadIds.includes(message.id) ? { ...message, is_read: true } : message
      )
    );

    const { error } = await supabase
      .from("sms_messages")
      .update({ is_read: true, updated_at: new Date().toISOString() })
      .in("id", unreadIds);

    if (error) {
      console.error("Unable to mark messages as read:", error);
      setNotice({ tone: "warning", message: "The conversation opened, but read status could not be saved." });
      await loadMessages(false);
    }
  }

  async function sendReply() {
    if (!selectedConversation) {
      setNotice({ tone: "warning", message: "Select a conversation first." });
      return;
    }

    const cleanedMessage = replyMessage.trim();
    if (!cleanedMessage) return;

    setSending(true);
    setNotice(null);

    try {
      const response = await fetch("/api/sms/reply", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          phone: selectedConversation.phone,
          guestId: selectedConversation.guestId,
          guestName: selectedConversation.guestName,
          message: cleanedMessage,
        }),
      });

      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(result.error || result.message || "Unable to send your reply.");
      }

      setReplyMessage("");
      setNotice({
        tone: result.warning ? "warning" : "success",
        message: result.warning || "Reply sent successfully.",
      });

      if (result.sms) {
        setMessages((currentMessages) => {
          const withoutDuplicate = currentMessages.filter((message) => message.id !== result.sms.id);
          return [...withoutDuplicate, result.sms as SmsMessage].sort(
            (a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
          );
        });
      } else {
        await loadMessages(false);
      }
    } catch (error) {
      setNotice({
        tone: "error",
        message: error instanceof Error ? error.message : "Unable to send your reply.",
      });
    } finally {
      setSending(false);
    }
  }

  const noticeClasses = {
    success: "border-green-500/30 bg-green-500/10 text-green-300",
    warning: "border-yellow-500/30 bg-yellow-500/10 text-yellow-200",
    error: "border-red-500/30 bg-red-500/10 text-red-300",
  };

  return (
    <div className="min-h-screen bg-black text-white">
      <Sidebar />

      <main className="min-h-screen lg:pl-64">
        <div className="border-b border-white/10 bg-black/90 px-4 py-5 backdrop-blur md:px-8">
          <div className="mx-auto flex max-w-7xl items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-3">
                <h1 className="text-2xl font-bold md:text-3xl">Conversations</h1>
                {totalUnread > 0 && (
                  <span className="rounded-full bg-red-500 px-3 py-1 text-xs font-bold text-white">
                    {totalUnread} unread
                  </span>
                )}
              </div>
              <p className="mt-1 text-sm text-white/50">
                Manage one-to-one guest conversations from your CRM.
              </p>
            </div>

            <button
              type="button"
              onClick={() => void loadMessages(true)}
              className="rounded-xl border border-white/15 bg-white/5 px-4 py-2 text-sm font-medium transition hover:bg-white/10"
            >
              Refresh
            </button>
          </div>
        </div>

        <div className="mx-auto max-w-7xl p-4 md:p-8">
          {notice && (
            <div className={`mb-4 rounded-xl border px-4 py-3 text-sm ${noticeClasses[notice.tone]}`}>
              {notice.message}
            </div>
          )}

          <div className="h-[calc(100vh-190px)] min-h-[620px] overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03] shadow-2xl">
            <div className="grid h-full min-h-0 lg:grid-cols-[360px_1fr]">
              <div className={mobileConversationOpen ? "hidden lg:block" : "block"}>
                <ConversationList
                  conversations={conversations}
                  selectedPhone={selectedPhone}
                  search={search}
                  loading={loading}
                  onSearch={setSearch}
                  onSelect={(phone) => void selectConversation(phone)}
                />
              </div>

              <section className={`${mobileConversationOpen ? "flex" : "hidden lg:flex"} min-h-0 min-w-0 flex-col`}>
                <ChatWindow
                  conversation={selectedConversation}
                  onBack={() => setMobileConversationOpen(false)}
                />
                {selectedConversation && (
                  <ReplyComposer
                    value={replyMessage}
                    sending={sending}
                    onChange={setReplyMessage}
                    onSend={() => void sendReply()}
                  />
                )}
              </section>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
