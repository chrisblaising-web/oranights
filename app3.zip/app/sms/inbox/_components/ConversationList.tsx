"use client";

import { Conversation } from "./types";
import { formatConversationTime, formatPhone } from "./chatUtils";

type Props = {
  conversations: Conversation[];
  selectedPhone: string | null;
  search: string;
  loading: boolean;
  onSearch: (value: string) => void;
  onSelect: (phone: string) => void;
};

export default function ConversationList({
  conversations,
  selectedPhone,
  search,
  loading,
  onSearch,
  onSelect,
}: Props) {
  const term = search.trim().toLowerCase();
  const filtered = term
    ? conversations.filter((conversation) =>
        [conversation.guestName || "", conversation.phone, conversation.lastMessage]
          .some((value) => value.toLowerCase().includes(term))
      )
    : conversations;

  return (
    <section className="flex h-full min-h-0 flex-col border-white/10 bg-zinc-950 lg:border-r">
      <div className="border-b border-white/10 p-4">
        <input
          type="search"
          value={search}
          onChange={(event) => onSearch(event.target.value)}
          placeholder="Search guest, phone or message..."
          className="w-full rounded-xl border border-white/10 bg-black px-4 py-3 text-sm text-white outline-none transition placeholder:text-white/30 focus:border-white/30"
        />
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto">
        {loading ? (
          <div className="p-8 text-center text-sm text-white/50">Loading conversations...</div>
        ) : filtered.length === 0 ? (
          <div className="p-8 text-center">
            <p className="font-semibold">No conversations yet</p>
            <p className="mt-2 text-sm text-white/45">
              New guest replies and sent messages will appear here.
            </p>
          </div>
        ) : (
          filtered.map((conversation) => {
            const selected = conversation.phone === selectedPhone;
            const initial = conversation.guestName?.charAt(0).toUpperCase() || "#";

            return (
              <button
                key={conversation.phone}
                type="button"
                onClick={() => onSelect(conversation.phone)}
                className={`flex w-full gap-3 border-b border-white/5 p-4 text-left transition ${
                  selected ? "bg-white/10" : "hover:bg-white/[0.05]"
                }`}
              >
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-white/10 text-lg font-bold">
                  {initial}
                </div>

                <div className="min-w-0 flex-1">
                  <div className="flex items-start justify-between gap-3">
                    <p className="truncate font-semibold">
                      {conversation.guestName || "Unknown Guest"}
                    </p>
                    <span className="shrink-0 text-xs text-white/40">
                      {formatConversationTime(conversation.lastMessageDate)}
                    </span>
                  </div>

                  <p className="mt-0.5 truncate text-xs text-white/45">
                    {formatPhone(conversation.phone)}
                  </p>

                  <div className="mt-2 flex items-center justify-between gap-2">
                    <p className={`truncate text-sm ${
                      conversation.unreadCount > 0 ? "font-semibold text-white" : "text-white/55"
                    }`}>
                      {conversation.lastDirection === "outbound" ? "You: " : ""}
                      {conversation.lastMessage}
                    </p>
                    {conversation.unreadCount > 0 && (
                      <span className="flex h-6 min-w-6 shrink-0 items-center justify-center rounded-full bg-red-500 px-2 text-xs font-bold">
                        {conversation.unreadCount}
                      </span>
                    )}
                  </div>
                </div>
              </button>
            );
          })
        )}
      </div>
    </section>
  );
}
